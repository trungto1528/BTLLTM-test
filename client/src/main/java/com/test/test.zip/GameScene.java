package com.test;

import java.util.ArrayList;
import java.util.List;

import javafx.animation.AnimationTimer;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class GameScene extends Pane {

    // =========================
    // VIEWPORT
    // =========================

    private static final double VIEW_WIDTH = 800;
    private static final double VIEW_HEIGHT = 600;

    // =========================
    // MAP
    // =========================

    private static final double MAP_WIDTH = 800;
    private static final double MAP_HEIGHT = 1800;

    private static final double FLOOR_HEIGHT = 600;

    // =========================
    // WORLD
    // =========================

    private final Pane world = new Pane();

    private final Player player;

    private final List<Platform> platforms = new ArrayList<>();
    // =========================
    // JUMP POWER BAR
    // =========================

    private final Rectangle jumpBarBackground = new Rectangle(40, 6);

    private final Rectangle jumpBarFill = new Rectangle(0, 6);

    // =========================
    // CAMERA
    // =========================

    private double cameraY = 1200;

    private int currentFloor = 0;

    // =========================
    // CONSTRUCTOR
    // =========================

    public GameScene() {

        setPrefSize(
                VIEW_WIDTH,
                VIEW_HEIGHT);

        /*
         * WORLD
         *
         * World chứa toàn bộ map.
         */
        world.setPrefSize(
                MAP_WIDTH,
                MAP_HEIGHT);

        getChildren().add(world);

        /*
         * PLAYER
         *
         * Bắt đầu ở tầng 0.
         *
         * Platform:
         * x = 100
         * y = 1650
         * width = 250
         *
         * Player cao 30:
         * y = 1650 - 30 = 1620
         */
        player = new Player(
                180,
                1620);

        world.getChildren().add(player);
        // Jump power bar
        jumpBarBackground.setFill(Color.GRAY);
        jumpBarFill.setFill(Color.ORANGE);

        world.getChildren().add(jumpBarBackground);
        world.getChildren().add(jumpBarFill);

        /*
         * Tạo map
         */
        createMap();

        /*
         * Input
         */
        setupInput();

        /*
         * Camera ban đầu
         */
        updateCamera();

        /*
         * Focus keyboard
         */
        javafx.application.Platform.runLater(
                this::requestFocus);
    }

    // =====================================================
    // CREATE MAP
    // =====================================================
    private void updateJumpBar() {

        /*
         * Thanh nằm phía trên đầu player.
         */

        double barWidth = 40;

        double barX = player.getX()
                + player.getWidth() / 2
                - barWidth / 2;

        double barY = player.getY()
                - 12;

        jumpBarBackground.setX(barX);
        jumpBarBackground.setY(barY);

        /*
         * Lấy phần trăm lực nhảy.
         */

        double ratio = player.getJumpPowerRatio();

        jumpBarFill.setX(barX);
        jumpBarFill.setY(barY);

        jumpBarFill.setWidth(
                barWidth * ratio);
    }

    private void createMap() {

        /*
         * =================================================
         * TẦNG 2
         * Y: 0 -> 600
         * =================================================
         */

        addPlatform(
                100,
                520,
                250,
                20);

        addPlatform(
                400,
                420,
                250,
                20);

        addPlatform(
                600,
                300,
                180,
                20);

        addPlatform(
                300,
                180,
                200,
                20);

        /*
         * =================================================
         * TẦNG 1
         * Y: 600 -> 1200
         * =================================================
         */

        addPlatform(
                50,
                1050,
                250,
                20);

        addPlatform(
                300,
                950,
                220,
                20);

        addPlatform(
                500,
                820,
                220,
                20);

        addPlatform(
                650,
                700,
                120,
                20);

        /*
         * =================================================
         * TẦNG 0
         * Y: 1200 -> 1800
         * =================================================
         */

        addPlatform(
                100,
                1650,
                250,
                20);

        addPlatform(
                350,
                1550,
                220,
                20);

        addPlatform(
                550,
                1420,
                200,
                20);

        addPlatform(
                250,
                1300,
                180,
                20);

        /*
         * =================================================
         * TƯỜNG TRÁI
         * =================================================
         */

        addPlatform(
                0,
                0,
                20,
                MAP_HEIGHT);

        /*
         * =================================================
         * TƯỜNG PHẢI
         * =================================================
         */

        addPlatform(
                MAP_WIDTH - 20,
                0,
                20,
                MAP_HEIGHT);

        /*
         * =================================================
         * SÀN ĐÁY
         * =================================================
         */

        addPlatform(
                0,
                MAP_HEIGHT - 20,
                MAP_WIDTH,
                20);
    }

    // =====================================================
    // ADD PLATFORM
    // =====================================================

    private void addPlatform(
            double x,
            double y,
            double width,
            double height) {

        Platform platform = new Platform(
                x,
                y,
                width,
                height);

        platforms.add(platform);

        /*
         * Platform thuộc WORLD
         */
        world.getChildren().add(platform);
    }

    // =====================================================
    // CAMERA
    // =====================================================

    private void updateCamera() {

        /*
         * =================================================
         * XÁC ĐỊNH TẦNG
         * =================================================
         *
         * Y nhỏ = tầng cao.
         * Y lớn = tầng thấp.
         *
         * 0 -> tầng 2
         * 600 -> tầng 1
         * 1200 -> tầng 0
         */

        int newFloor = 2
                - (int) (player.getY()
                        / FLOOR_HEIGHT);

        /*
         * Giới hạn tầng
         */

        if (newFloor < 0) {
            newFloor = 0;
        }

        if (newFloor > 2) {
            newFloor = 2;
        }

        currentFloor = newFloor;

        /*
         * =================================================
         * CAMERA Y
         * =================================================
         *
         * Tầng 0:
         * camera nhìn Y 1200 -> 1800
         *
         * Tầng 1:
         * camera nhìn Y 600 -> 1200
         *
         * Tầng 2:
         * camera nhìn Y 0 -> 600
         */

        cameraY = (2 - currentFloor)
                * FLOOR_HEIGHT;

        /*
         * =================================================
         * APPLY CAMERA
         * =================================================
         *
         * Không camera X.
         *
         * Toàn bộ chiều ngang map luôn hiển thị.
         */

        world.setTranslateX(0);

        world.setTranslateY(
                -cameraY);
    }

    // =====================================================
    // INPUT
    // =====================================================

    private void setupInput() {

        setFocusTraversable(true);

        /*
         * KEY PRESSED
         */

        setOnKeyPressed(event -> {

            /*
             * TRÁI
             */

            if (event.getCode() == KeyCode.A
                    || event.getCode() == KeyCode.LEFT) {

                player.setMovingLeft(true);
            }

            /*
             * PHẢI
             */

            if (event.getCode() == KeyCode.D
                    || event.getCode() == KeyCode.RIGHT) {

                player.setMovingRight(true);
            }

            /*
             * CHARGE JUMP
             */

            if (event.getCode() == KeyCode.SPACE) {

                player.startCharging();
            }
        });

        /*
         * KEY RELEASED
         */

        setOnKeyReleased(event -> {

            /*
             * THẢ TRÁI
             */

            if (event.getCode() == KeyCode.A
                    || event.getCode() == KeyCode.LEFT) {

                player.setMovingLeft(false);
            }

            /*
             * THẢ PHẢI
             */

            if (event.getCode() == KeyCode.D
                    || event.getCode() == KeyCode.RIGHT) {

                player.setMovingRight(false);
            }

            /*
             * THẢ SPACE
             */

            if (event.getCode() == KeyCode.SPACE) {

                player.releaseJump();
            }
        });
    }

    // =====================================================
    // GAME LOOP
    // =====================================================

    protected void startLoop() {

        AnimationTimer timer = new AnimationTimer() {

            private long lastTime = 0;

            @Override
            public void handle(long now) {

                /*
                 * Frame đầu tiên
                 */

                if (lastTime == 0) {

                    lastTime = now;

                    return;
                }

                /*
                 * Delta time
                 */

                double deltaTime = (now - lastTime)
                        / 1_000_000_000.0;

                /*
                 * Tránh delta quá lớn
                 * khi window bị lag.
                 */

                if (deltaTime > 0.05) {
                    deltaTime = 0.05;
                }

                lastTime = now;

                /*
                 * Charge jump
                 */

                player.chargeJump(deltaTime);

                player.update(
                        deltaTime,
                        platforms);

                updateCamera();

                updateJumpBar();
            }
        };

        timer.start();
    }
}