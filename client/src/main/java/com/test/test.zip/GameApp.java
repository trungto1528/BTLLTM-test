package com.test;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class GameApp extends Application {

    @Override
    public void start(Stage stage) {

        GameScene gameScene = new GameScene();

        Scene scene = new Scene(gameScene, 800, 600);

        stage.setTitle("Jump King Multiplayer");
        stage.setScene(scene);
        stage.show();

        gameScene.requestFocus();
        gameScene.startLoop();
    }
}